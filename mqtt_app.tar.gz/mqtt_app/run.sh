#!/bin/sh

#cmd   devid proid api-key
./mqttc 
